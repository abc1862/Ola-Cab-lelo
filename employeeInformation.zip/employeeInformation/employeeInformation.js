import { LightningElement } from 'lwc';
import getEmployee from '@salesforce/apex/EmployeeDataController.getEmployee';
import deleteEmployee from '@salesforce/apex/EmployeeDataController.deleteEmployee';
import Name from '@salesforce/schema/Employee_Data__c.Name';
import Email from '@salesforce/schema/Employee_Data__c.Email__c';
import Company from '@salesforce/schema/Employee_Data__c.Company__c';
export default class EmployeeInformation extends LightningElement {
    empList;
    showNew=false;
    showEdit=false;
    bShowModal=false;
    editId;
    fields = [Name, Email, Company];
    columns = [
        { label: 'Name', fieldName: 'Name' },
        { label: 'Email', fieldName: 'Email__c'},
        { label: 'Company', fieldName: 'Company__c'}
    ];
    connectedCallback(){
        this.refreshList();
     }

     
     refreshList(){
         getEmployee()
         .then(result=>{
             this.empList=result;
         });
     }
     createEmployee(){
        
        this.showNew=true;
        this.bShowModal=true;
     
        
     }
     editEmployee(){
        this.editId=this.template.querySelector('lightning-datatable').getSelectedRows()[0].Id;
        this.showEdit=true;
        this.bShowModal=true;
    }
    deleteEmployee(){
        var n=this.template.querySelector('lightning-datatable').getSelectedRows().length;
        console.log('length : ' + n);
        var i;
        var idList=[];
        for(i=0;i<n;i++){
            idList[i]=(this.template.querySelector('lightning-datatable').getSelectedRows()[i].Id);
        }
        console.log('list of Id ' + idList);
        deleteEmployee({'idList':idList})
            .then(result=>{
                console.log('Deleted ' + result);
                this.refreshList();
            });
    }
     closeModal(){
        this.refreshList();
        this.bShowModal=false;
        this.showNew=false;
        this.showEdit=false;
    }
    
}